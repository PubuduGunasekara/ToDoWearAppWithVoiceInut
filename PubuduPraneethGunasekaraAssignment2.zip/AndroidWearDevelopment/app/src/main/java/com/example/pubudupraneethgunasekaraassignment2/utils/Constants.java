package com.example.pubudupraneethgunasekaraassignment2.utils;

public class Constants {
    public static final int ACTION_ADD = 9001;
}
